package com.example.krasrakas;

public class StatusData {
    String name, time;
    int ingredients, desc;
    int image;
    public StatusData(String name, String time, int ingredients, int desc, int image) {
        this.name = name;
        this.time = time;
        this.ingredients = ingredients;
        this.desc = desc;
        this.image = image;
    }
}
